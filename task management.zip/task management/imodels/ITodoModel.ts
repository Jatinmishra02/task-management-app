export interface ITodoModel {
    id:   number;
    text: string;
    done: boolean;
}
