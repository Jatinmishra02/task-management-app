import React from "react";

const WithMongoDBIndex = () => {
  return <div>Mongo DB here pls</div>;
};

export default WithMongoDBIndex;
