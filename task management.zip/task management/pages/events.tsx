import React from "react";

const Eventsssss = () => {
  return <div>Let us make a event!</div>;
};

export default Eventsssss;
