import React from "react";

const UsersIndexPage = () => {
  return <div>Hello to All Users!</div>;
};

export default UsersIndexPage;
