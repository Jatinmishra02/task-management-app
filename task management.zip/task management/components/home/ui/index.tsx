import React from "react";
import HomeUI from "./HomeUI";

const HomeCompIndex = () => {
  return (
    <div>
      <HomeUI></HomeUI>
    </div>
  );
};

export default HomeCompIndex;
