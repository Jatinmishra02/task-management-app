This is a Next.js project with TypeScript, Mobx for easy State Management, Chakra UI to make beautiful UI easily and MongoDB(soon).
## https://learn-next-js-alpha.vercel.app/todos 
(on mobile use Chrome to open the site) 

## Note: Main branch has all the latest Code. Switch branch to get the code of a particular youtube lesson video.

## Playlist link : https://www.youtube.com/watch?v=I_OyftH2LEQ&list=PL1xjvXM_PQWwVkZYPE9Rbt_Mmsz8BEZ3S
## Our Amazing Youtube Playlist (Next.js with TypeScript, Mobx, Chakra UI and MongoDB ) link:
https://youtube.com/playlist?list=PL1xjvXM_PQWxZ802QXOs9E9IEQTTZk_yf
## Useful Notion link which has resources and commands.
https://www.notion.so/Next-js-with-TypeScript-Mobx-Chakra-UI-and-MongoDB-soon-ee129e2e49304983930add42bd345ea9


## Getting Started
Watch our YouTube Playlist to build this Responsive website 
https://youtube.com/playlist?list=PL1xjvXM_PQWxZ802QXOs9E9IEQTTZk_yf

OR
1. Clone the repo 
2. in Terminal run npm run dev
3. in browser open http://localhost:3000/
